#include "dragon_cave.hpp"

// Define DragonCave's methods here
