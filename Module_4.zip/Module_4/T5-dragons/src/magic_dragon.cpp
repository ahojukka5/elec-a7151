#include "magic_dragon.hpp"

// Define MagicDragon's methods here
