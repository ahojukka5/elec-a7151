#include "first.hpp"

#include <iostream>

void Hello() {
  // Write here the line that prints "Hello world!" and a newline.
  // Hint: if your output is empty in the tests, remember the part about
  // flushing!
  }
