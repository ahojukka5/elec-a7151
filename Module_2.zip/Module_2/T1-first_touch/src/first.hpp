#ifndef AALTO_ELEC_CPP_FIRST
#define AALTO_ELEC_CPP_FIRST

/**
 * \brief Output "Hello world!" string in standard output stream.
 *
 */
void Hello();

#endif
