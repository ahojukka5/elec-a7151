#include <iostream>

#include "first.hpp"

int main(void) {
  Hello();

  return 0;
}
