#include <iostream>

#include "vector_strings.hpp"

int main(void) {
  CMDReader();
  return 0;
}
