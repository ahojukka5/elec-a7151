#include "vector_strings.hpp"

#include <iostream>
#include <vector>

void Adder(std::vector<std::string>& names) {
  
}

void Remover(std::vector<std::string>& names) {
  
}

void Printer(std::vector<std::string>& names) {
  
}

void CMDReader() {
  
}
