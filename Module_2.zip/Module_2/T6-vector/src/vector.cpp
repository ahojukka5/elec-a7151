#include "vector.hpp"

#include <vector>

int GetMin(std::vector<int> v) {
  
  return 0; 
}

int GetMax(std::vector<int> v) {
  
  return 0; 
}

double GetAvg(std::vector<int> v) {
  
  return 0.0; 
}
