#include "boat.hpp"
//TODO: implement Boat's members
