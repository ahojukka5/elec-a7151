#include "register.hpp"
//TODO: implement Register's members
