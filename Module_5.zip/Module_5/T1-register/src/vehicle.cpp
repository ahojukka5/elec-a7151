#include "vehicle.hpp"
//TODO: implement Vehicle's members
