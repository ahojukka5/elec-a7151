#include <stdio.h>

int main(void) {
	/* Copy the line after this comment. */
		return 0;
}
