#include "vector_it.hpp"

#include <iostream>
#include <vector>

// Implement the functions here

std::vector<int> ReadVector() {
  std::vector<int> v;
  
  return v;
}

void PrintSum1(const std::vector<int>& v) {
  
}

void PrintSum2(const std::vector<int>& v) {
  
}
