#include "list.hpp"

#include <iostream>

// Implement the functions here

std::istream& GetLines(std::istream& is, std::list<std::string>& list) {
  
}

void Print(const std::list<std::string>& list) {
  
}

void SortAndUnique(std::list<std::string>& list) {
  
}