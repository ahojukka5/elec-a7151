#include "matrix.hpp"

#include <iostream>
#include <vector>

// Implement the functions here
// Remember to use auto and ranged for-loops when they can be used!

// Assumes 'm' is a square matrix
Matrix ReadMatrix(int n) {
  }

Matrix Rotate90Deg(const Matrix &m) {
  }

void Print(const Matrix &m) {
  }
